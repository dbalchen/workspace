#! /usr/contrib/bin/perl

print "Crazy Baby\n";

exit(0);
